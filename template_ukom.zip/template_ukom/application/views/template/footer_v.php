<footer class="bg-warning text-center text-lg-start">
  <!-- Copyright -->
  <div class="text-center p-3">
    © 2021 Copyright:
    <a class="text-dark" href="https://github.com/AdanRafli/">Adan Rafli</a>
  </div>
  <!-- Copyright -->
</footer>